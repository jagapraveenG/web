package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonorsApplication.class, args);
	}

}
