package com.example.demo;

import java.util.concurrent.Flow.Subscription;

/**
* Sends email notification.
*/
public interface EmailNotifierService {
/**
* Notifies subscriber, that the minPrice has decreased.
*
* @paramsubscription the {@link Subscription} object.
* @param oldMinPrice minPrice before recount.
* @paramnewMinPrice minPrice after recount.
*/
void notifySubscriber(Subscription subscription, Integer oldMinPrice, Integer newMinPrice);
/**
* Notifies subscriber, that subscription has added.
*
* @paramsubscription the {@link Subscription} object.
*/
void notifyAddingSubscription(Subscription subscription);
}
