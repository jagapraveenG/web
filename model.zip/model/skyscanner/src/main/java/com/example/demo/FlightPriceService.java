package com.example.demo;

import java.util.concurrent.Flow.Subscription;

/**
* Sends email notification.
*/
public interface FlightPriceService {
/**
* Notifies subscriber, that the minPrice has decreased.
*
* @param subscription the {@link Subscription} object.
* @param oldMinPrice minPrice before recount.
* @param newMinPrice minPrice after recount.
*/
void notifySubscriber(Subscription subscription, Integer oldMinPrice, Integer newMinPrice);
/**
* Notifies subscriber, that subscription has added.
*
* @param subscription the {@link Subscription} object.
*/
void notifyAddingSubscription(Subscription subscription);
}
