package com.example.demo;
import java.util.List;
/**
* Manipulates with subscriptions.
*/
public interface SubscriptionService {
/**
* Add new subscription.
* @paramdto the dto of the subscription.
*/
SubscriptionDto create(SubscriptionCreateDto dto);
/**
* Get all subscription based on email.
*
* @paramemail provided email;
* @return the collection of the {@link SubscriptionDto} objects.
*/
List<SubscriptionDto> findByEmail(String email);
/**
* Remove subscription based on it ID
*
* @paramsubscriptionId the ID of the {@link Subscription}.
*/
void delete(Long subscriptionId);
/**
* Update subscription based on ID
*
*
* @paramsubscriptionId the ID of the subscription to be updated.
* @paramdto the data to be updated.
* @return updated {@link SubscriptionDto}.
*/
SubscriptionDto update(Long subscriptionId, SubscriptionUpdateDto dto);
}
