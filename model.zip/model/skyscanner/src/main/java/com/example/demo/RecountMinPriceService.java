package com.example.demo;
/**
* Recounts minPrice for all the
subscriptions.
*/
public interface RecountMinPriceService {
/**
* Recounts minPrice for all the
subscriptions.
*/
void recount();
}
